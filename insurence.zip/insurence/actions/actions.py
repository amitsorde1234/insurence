# This files contains your custom actions which can be used to run
# custom Python code.
#
# See this guide on how to implement these action:
# https://rasa.com/docs/rasa/custom-actions


# This is a simple example for a custom action which utters "Hello World!"

from typing import Any, Text, Dict, List
from rasa_sdk import Action, Tracker
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk.events import Restarted
class name1:
    def username(self,name2):
        self.name2=name2
    def getusername(self):
        return self.name2
class number1:
    def usernumber(self,number2):
        self.number2=number2
    def getnumber(self):
        return self.number2
a=name1()
b=number1()

class ActionHelloWorld(Action):
    def name(self):
        return "action_ask_fullname"
    def run(self, dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        person = tracker.get_slot('PERSON')
        a.username(person)
        y=a.getusername()
        dispatcher.utter_message(text="your name is " + y)
        return[]
class phonenu(Action):
    def name(self):
        return "action_ask_phonenumber"
    def run(self, dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        phone = tracker.get_slot('phonenumber')
        b.usernumber(phone)
        y1=b.getnumber()
        dispatcher.utter_message(text="your phone is " + y1 )
        dispatcher.utter_message(text="your name is "+ a.getusername() +"\n your phone is " + y1)
     
        return[]

class ActionRestarted(Action):
    def name(self):
        return "action_bot_restart"

    def run(self, dispatcher, tracker, domain):
        return [Restarted()]
